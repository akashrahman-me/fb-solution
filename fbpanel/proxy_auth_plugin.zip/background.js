
var config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "dc.oxylabs.io",
            port: parseInt(8000)
        },
        bypassList: ["localhost"]
    }
};

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

chrome.webRequest.onAuthRequired.addListener(
    function(details) {
        return {
            authCredentials: {
                username: "user-akash_sAIls-country-US",
                password: "83QcuHmvdK8_yrv"
            }
        };
    },
    {urls: ["<all_urls>"]},
    ['blocking']
);
